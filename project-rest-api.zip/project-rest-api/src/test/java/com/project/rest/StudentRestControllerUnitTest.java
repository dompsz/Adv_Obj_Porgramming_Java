package com.project.rest;

public class StudentRestControllerUnitTest {

}
