package com.project.rest;

public class StudentRestControllerIntegrationTest {

}
